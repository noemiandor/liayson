		CHANGES IN LIAYSON VERSION 1.0.4

OTHER CHANGES
    o runLiayson now also fails gracefully if service is not available.

		CHANGES IN LIAYSON VERSION 1.0.3

OTHER CHANGES
    o Changed bioMart GRCH38 link to work around temporary Ensembl web service issue. Fail gracefully if service isnot available via this new link either.

		CHANGES IN LIAYSON VERSION 1.0.2

OTHER CHANGES
    o Changed seed in clusterCells example to ensure compatibility with new implementation of function 'sample' in R 3.6

		CHANGES IN LIAYSON VERSION 1.0.1

NEW FEATURES
    o Separate preprocessing (aggregateSegmentExpression), main functionality (segmentExpression2CopyNumber), and postprocessing (clusterCells) steps are available

OTHER CHANGES	
    o Completed documentation
